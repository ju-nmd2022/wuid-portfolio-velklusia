(/It initializes animations on my website/)
AOS.init();